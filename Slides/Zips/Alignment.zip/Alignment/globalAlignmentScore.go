package main

//GlobalScoreTable takes two strings and alignment penalties. It returns a 2-D array
//holding dynamic programming scores for global alignment with these penalties.
func GlobalScoreTable(str1, str2 string, match, mismatch, gap float64) [][]float64 {
	return [][]float64{}
}
