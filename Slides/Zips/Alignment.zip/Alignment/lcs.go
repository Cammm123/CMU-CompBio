package main

//LongestCommonSubsequence takes two strings as input.
//It returns a longest common subsequence of the two strings.
func LongestCommonSubsequence(str1, str2 string) string {
	return ""
}
