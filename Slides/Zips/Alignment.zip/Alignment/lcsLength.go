package main

//LCSLength takes two strings as input. It returns the length of a longest common
//subsequence of the two strings.
func LCSLength(str1, str2 string) int {
	return 0
}
