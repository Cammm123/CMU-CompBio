package main

//LocalScoreTable takes two strings and alignment penalties. It returns a 2-D array
//holding dynamic programming scores for local alignment with these penalties.
func LocalScoreTable(str1, str2 string, match, mismatch, gap float64) [][]float64 {
	return [][]float64{}
}
