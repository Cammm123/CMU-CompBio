Copy the Alignment folder into your "go/src" directory.

Then, write each of the missing functions in the Alignment folder.

The "Data" folder contains some datasets that we will use; chiefly, a few hemoglobin subunit alpha proteins for animals, as well as the SARS-CoV and SARS-CoV-2 whole genomes. The "Output" folder will contain the results of running some code on these genomes.