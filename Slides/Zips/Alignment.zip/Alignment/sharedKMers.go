package main

//CountSharedKmers takes two strings and an integer k. It returns the number of
//k-mers that are shared by the two strings.
func CountSharedKmers(str1, str2 string, k int) int {
	return 0
}
