package main

//BinarizeMatrix takes a matrix of values and a threshold.
//It binarizes the matrix according to the threshold.
//If entries across main diagonal are both above threshold, only retain the bigger one.
func BinarizeMatrix(mtx [][]float64, threshold float64) [][]int {
	return [][]int{}
}
