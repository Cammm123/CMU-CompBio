package main

import (
	"fmt"
)

func main() {
	fmt.Println("Genome assembly!")
}
