package main

//Minimizer takes a string text and an integer k as input.
//It returns the k-mer of text that is lexicographically minimum.
func Minimizer(text string, k int) string {
	return ""
}
