package main

//GenerateRandomGenome takes a parameter length and returns
//a random DNA string of this length where each nucleotide has equal probability.
func GenerateRandomGenome(length int) string {
	return ""
}
