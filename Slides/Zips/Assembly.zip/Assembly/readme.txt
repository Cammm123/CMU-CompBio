Copy the Assembly folder into your "go/src" directory.

Then, write each of the missing functions in the directory. If you need a subroutine, please feel free to place it in the same file.

The "Data" folder contains the SARS-CoV and SARS-CoV-2 genomes along with a collection of SARS-CoV reads.

