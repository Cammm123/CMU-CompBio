package main

import (
	"fmt"
)

func main() {
	fmt.Println("Coding the Game of Life!")
}
