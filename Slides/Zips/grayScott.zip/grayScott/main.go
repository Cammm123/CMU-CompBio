package main

import (
	"fmt"
)

func main() {
	fmt.Println("Let's hack the Gray-Scott model!")
}
