// Package draw2dgl provides a graphic context that can draw vector
// graphics and text on OpenGL.
package draw2dgl
